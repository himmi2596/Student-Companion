package student_companion;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.sql.*;
import javax.swing.JOptionPane;

public class Admin_Login extends javax.swing.JFrame {
    Dimension d;
    int w,h;
    public Admin_Login() 
    {
        initComponents();
        d = Toolkit.getDefaultToolkit().getScreenSize();
        w = d.width;
        h = d.height;
        this.setSize(d);
        this.setVisible(true);
        this.setDefaultCloseOperation(2);
        username.setText("Rohan Joshi");
        password.setText("rj@joshi");
        this.setDefaultCloseOperation(2);
    }
    public Admin_Login(String s) 
    {
        initComponents();
        d = Toolkit.getDefaultToolkit().getScreenSize();
        w = d.width;
        h = d.height;
        this.setSize(d);
        username.setText("");
        password.setText("");
        this.setSize(500,500);
        this.setVisible(true);
        this.setDefaultCloseOperation(2);
    }
     

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        username = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        password = new javax.swing.JPasswordField();
        jLabel3 = new javax.swing.JLabel();
        bt1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);
        getContentPane().add(username);
        username.setBounds(186, 49, 111, 20);

        jLabel1.setText("Username");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(32, 49, 73, 20);

        jLabel2.setText("Password");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(32, 95, 70, 14);
        getContentPane().add(password);
        password.setBounds(186, 92, 110, 20);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel3.setText("ADMIN LOGIN");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(150, 0, 210, 43);

        bt1.setText("LOGIN");
        bt1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt1ActionPerformed(evt);
            }
        });
        getContentPane().add(bt1);
        bt1.setBounds(180, 180, 70, 40);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bt1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt1ActionPerformed
        if (username.getText().isEmpty() || password.getText().isEmpty()) {
            JOptionPane.showMessageDialog(Admin_Login.this, "All Fields are Required!!");
        } else 
        {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                System.out.println("Driver loading");
                Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student_companion", "root", "system");
                System.out.println("connection built");
                Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                ResultSet rs = stmt.executeQuery("select * from admin");
                Boolean flag = false;
                while(rs.next())
                {
                    if (rs.getString("Username").equals(username.getText()) && rs.getString("Password").equals(password.getText()))
                    {
                        JOptionPane.showMessageDialog(Admin_Login.this, "LOGIN SUCCESSFUL");
                        new AdminHome(username.getText()).setVisible(true);
                        flag=true;
                        Admin_Login.this.dispose();
                    }
                }
                if(!flag)
                {
                        JOptionPane.showMessageDialog(Admin_Login.this, "Username is wrong");
                        password.setText("");
                        username.setText("");
                }
            } 
            catch (Exception ex) 
            {
                ex.printStackTrace();
            }
        }
    }//GEN-LAST:event_bt1ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Admin_Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bt1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPasswordField password;
    private javax.swing.JTextField username;
    // End of variables declaration//GEN-END:variables
}
