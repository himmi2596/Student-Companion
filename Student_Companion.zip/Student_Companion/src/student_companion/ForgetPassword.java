package student_companion;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.Socket;
import javax.swing.JOptionPane;

public class ForgetPassword extends javax.swing.JFrame {
    String request,password;
    String otp;
    public ForgetPassword() 
    {
        initComponents();
        this.setSize(500,500);
        Panel2.setVisible(false);
        this.setVisible(true);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Panel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        tf_Email = new javax.swing.JTextField();
        bt_Fetch = new javax.swing.JButton();
        Panel2 = new javax.swing.JPanel();
        bt_Verify = new javax.swing.JButton();
        lb_Verify = new javax.swing.JLabel();
        lb_Verify1 = new javax.swing.JLabel();
        tf_Verify = new javax.swing.JTextField();
        lb_ph = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(153, 153, 255));
        getContentPane().setLayout(null);

        Panel1.setBackground(new java.awt.Color(255, 255, 255));
        Panel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Panel1.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel1.setText("Enter your Registered Email :");
        Panel1.add(jLabel1);
        jLabel1.setBounds(20, 20, 170, 50);
        Panel1.add(tf_Email);
        tf_Email.setBounds(200, 30, 200, 30);

        bt_Fetch.setText("FETCH");
        bt_Fetch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_FetchActionPerformed(evt);
            }
        });
        Panel1.add(bt_Fetch);
        bt_Fetch.setBounds(160, 110, 80, 30);

        getContentPane().add(Panel1);
        Panel1.setBounds(20, 20, 450, 210);

        Panel2.setBackground(new java.awt.Color(255, 255, 255));
        Panel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Panel2.setLayout(null);

        bt_Verify.setText("Verify");
        bt_Verify.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_VerifyActionPerformed(evt);
            }
        });
        Panel2.add(bt_Verify);
        bt_Verify.setBounds(160, 150, 80, 30);

        lb_Verify.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lb_Verify.setText("Enter OTP");
        Panel2.add(lb_Verify);
        lb_Verify.setBounds(20, 70, 70, 50);

        lb_Verify1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lb_Verify1.setText("An OTP is Sent to this Mobile Number:");
        Panel2.add(lb_Verify1);
        lb_Verify1.setBounds(10, 10, 220, 50);
        Panel2.add(tf_Verify);
        tf_Verify.setBounds(130, 80, 210, 30);

        lb_ph.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Panel2.add(lb_ph);
        lb_ph.setBounds(240, 10, 130, 50);

        getContentPane().add(Panel2);
        Panel2.setBounds(20, 260, 450, 210);

        pack();
    }// </editor-fold>//GEN-END:initComponents
        public class Client implements Runnable {
        
        Socket sock;
        DataOutputStream dos;
        DataInputStream dis;
        FileOutputStream fos;
        Client() 
        {
            
        }
        
        public void run() {
            String res;
            try {
                    System.out.println("Client Request Send");
                    sock = new Socket("127.0.0.1", 9999);
                    System.out.println("Request Accepted by Server");
                    dos = new DataOutputStream(sock.getOutputStream());
                    dis = new DataInputStream(sock.getInputStream());
                    System.out.println("Stream Connected");
                
                    if(request.equals("fetchpassword"))
                    {
                        dos.writeBytes("fetchpassword\r\n");
                        
                        String email=tf_Email.getText();
                        if(email.isEmpty())
                        {
                            JOptionPane.showMessageDialog(ForgetPassword.this, "Please Enter Email");
                        }
                        else
                        {
                            dos.writeBytes(email+"\r\n");
                            String result=dis.readLine();
                            if(result.equals("fails"))
                            {
                                JOptionPane.showMessageDialog(ForgetPassword.this, "Please Enter Registered Email");
                                tf_Email.setText("");
                            }
                            else
                            {
                                otp=((int)(1000+(9999-1000)*Math.random()))+"";
                                String phno=dis.readLine();
                                password=dis.readLine();
                                System.out.println(phno);
                                System.out.println(password);
                                String n=phno.charAt(7)+""+phno.charAt(8)+""+phno.charAt(9);
                                lb_ph.setText("*******"+n);
                                new Thread(new sms_send(phno,"OTP For Fetch Password is "+otp+"","text")).start();
                                Thread.sleep(1000);
                                Panel2.setVisible(true);
                            }
                        }
                    }
                }
                catch (Exception ex) 
                {
                    ex.printStackTrace();
                }
            }
        }
    private void bt_FetchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_FetchActionPerformed
        request="fetchpassword";
        new Thread(new Client()).start();
    }//GEN-LAST:event_bt_FetchActionPerformed

    private void bt_VerifyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_VerifyActionPerformed
        String tfOtp=tf_Verify.getText();
        if(tfOtp.equals(otp))
        {
            SimpleMailDemo obj = new SimpleMailDemo("jaannashin02@gmail.com","Recover Password","Your Password for Project:"+password);
            JOptionPane.showMessageDialog(ForgetPassword.this,"Your Password is Sent to your Mail!!");
        }
        else
        {
            JOptionPane.showMessageDialog(ForgetPassword.this, "OTP DO NOT MATCHES");
        }
    }//GEN-LAST:event_bt_VerifyActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ForgetPassword.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ForgetPassword.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ForgetPassword.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ForgetPassword.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ForgetPassword().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Panel1;
    private javax.swing.JPanel Panel2;
    private javax.swing.JButton bt_Fetch;
    private javax.swing.JButton bt_Verify;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel lb_Verify;
    private javax.swing.JLabel lb_Verify1;
    private javax.swing.JLabel lb_ph;
    private javax.swing.JTextField tf_Email;
    private javax.swing.JTextField tf_Verify;
    // End of variables declaration//GEN-END:variables
}
