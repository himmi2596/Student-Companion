package student_companion;
public class Panel_Paper extends javax.swing.JPanel 
{
    public Panel_Paper() 
    {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lb_Description = new javax.swing.JLabel();
        lb_Upload = new javax.swing.JLabel();
        lb_Title1 = new javax.swing.JLabel();
        lb_icon = new javax.swing.JLabel();

        setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        setLayout(null);
        add(lb_Description);
        lb_Description.setBounds(20, 90, 360, 40);
        add(lb_Upload);
        lb_Upload.setBounds(160, 140, 220, 30);
        add(lb_Title1);
        lb_Title1.setBounds(170, 20, 140, 30);

        lb_icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/student_companion/untitled.png"))); // NOI18N
        add(lb_icon);
        lb_icon.setBounds(10, 10, 110, 60);
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JLabel lb_Description;
    public javax.swing.JLabel lb_Title1;
    public javax.swing.JLabel lb_Upload;
    public javax.swing.JLabel lb_icon;
    // End of variables declaration//GEN-END:variables
}
