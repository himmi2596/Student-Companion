package student_companion;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;
public class ViewAllDepartment extends javax.swing.JInternalFrame 
{
    ArrayList <Department> al;
    myTable dtm;
    public ViewAllDepartment() 
    {
        initComponents();
        this.al=new ArrayList<>();
        dtm=new myTable();
        jt.setModel(dtm);
        this.setSize(500,500);
        this.setVisible(true);
        this.setDefaultCloseOperation(2);
        this.fetchdata();
    }
    public void fetchdata()
    {
        al.clear();
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver loading");
            Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student_companion", "root", "system");
            System.out.println("connection built");
            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stmt.executeQuery("select * from department");
            while(rs.next())
            {
                Department dt= new Department();
                dt.Department_Name = rs.getString("Department_Name");
                dt.Description = rs.getString("Description");
                al.add(dt);
            }
            dtm.fireTableDataChanged();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
    class myTable extends AbstractTableModel
    {
        String title[] = {"DEPARTMENT","DESCRIPTION"};
        public String getColumnName(int index)
        {
            return title[index];
        }
        public int getColumnCount()
        {
            return 2;
        }
        public int getRowCount()
        {
            return al.size();
        }
        public Object getValueAt(int row, int col)
        {
            Department dt= al.get(row);
            if(col==0)
                return dt.Department_Name ;
            else
                return dt.Description;
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jt = new javax.swing.JTable();
        delete = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("ALL DEPARTMENT");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(130, 40, 240, 55);

        jt.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jt);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(30, 180, 420, 90);

        delete.setText("DELETE");
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });
        getContentPane().add(delete);
        delete.setBounds(180, 350, 69, 23);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
        String dt;
        int index = jt.getSelectedRow();
        if(index==-1)
        {
           JOptionPane.showMessageDialog(ViewAllDepartment.this, "Please Select row"); 
        }
        else
        {
            dt = al.get(index).Department_Name;
            System.out.println(dt);
            int flag = JOptionPane.showConfirmDialog(ViewAllDepartment.this,"Are you Sure?");
            if(flag ==JOptionPane.YES_OPTION)
            {
                try
                {
                    Class.forName("com.mysql.jdbc.Driver");
                    System.out.println("Driver loading");
                    Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student_companion", "root", "system");
                    System.out.println("connection built");
                    Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                    ResultSet rs = stmt.executeQuery("select * from department where Department_Name = '"+dt+"'");
                    if(rs.next())
                    {
                        rs.deleteRow();
                        JOptionPane.showMessageDialog(ViewAllDepartment.this, "Delete Successfully");
                        ViewAllDepartment.this.fetchdata();
                    }
                }
                catch(Exception ex)
                {
                    ex.printStackTrace();
                }
            }
        }
    }//GEN-LAST:event_deleteActionPerformed

    public static void main(String args[]) 
    {
        java.awt.EventQueue.invokeLater(new Runnable() 
        {
            public void run() 
            {
                new ViewAllDepartment().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton delete;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jt;
    // End of variables declaration//GEN-END:variables
}
