package student_companion;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.net.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;

public class StudentHome extends javax.swing.JFrame {
    ArrayList<Papers> al;
    Mymodel ptm;
    String path;
    String rollno;
    Socket sock;
    FileInputStream fis;
    String request = "",s="";

    public StudentHome(String rollno) 
    {
        try 
        {
            initComponents();
            al=new ArrayList<>();
            ptm=new Mymodel();
            this.rollno = rollno;
            jt.setModel(ptm);
            this.setSize(730, 650);
            this.setVisible(true);
            lb1.setText("WELCOME " + rollno);
            this.setDefaultCloseOperation(2);
            lb_year.setVisible(false);
            tf_year.setVisible(false);
        } 
        catch (Exception ex) 
        {
            ex.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bg = new javax.swing.ButtonGroup();
        jPanel3 = new javax.swing.JPanel();
        buttonGroup1 = new javax.swing.ButtonGroup();
        tb = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        p_search = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        lb_title1 = new javax.swing.JLabel();
        tf_search = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        rb_Note1 = new javax.swing.JRadioButton();
        rb_Paper1 = new javax.swing.JRadioButton();
        bt_search = new javax.swing.JButton();
        sp_search = new javax.swing.JScrollPane();
        mainpanel = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        spRecentNotes1 = new javax.swing.JScrollPane();
        spPanel1 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        spRecentNotes = new javax.swing.JScrollPane();
        spPanel = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        Myupload = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        cb_semester = new javax.swing.JComboBox<>();
        cb_subcode = new javax.swing.JComboBox<>();
        lb_title = new javax.swing.JLabel();
        lb_Discription = new javax.swing.JLabel();
        tf_title = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        ta_discription = new javax.swing.JTextArea();
        jLabel6 = new javax.swing.JLabel();
        rb_Note = new javax.swing.JRadioButton();
        rb_Paper = new javax.swing.JRadioButton();
        lb_year = new javax.swing.JLabel();
        tf_year = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        Add = new javax.swing.JButton();
        bt_browser = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jt = new javax.swing.JTable();
        bt_Delete = new javax.swing.JButton();
        bt_cancel = new javax.swing.JButton();
        p_Setting = new javax.swing.JPanel();
        password = new javax.swing.JButton();
        lb1 = new javax.swing.JLabel();

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        tb.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                tbStateChanged(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(153, 153, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(null);

        p_search.setBackground(new java.awt.Color(255, 255, 255));
        p_search.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        p_search.setLayout(null);

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setText("SEARCH PAPERS");
        p_search.add(jLabel7);
        jLabel7.setBounds(100, 10, 130, 30);

        lb_title1.setText("Search By Name:");
        p_search.add(lb_title1);
        lb_title1.setBounds(30, 60, 120, 20);
        p_search.add(tf_search);
        tf_search.setBounds(180, 60, 140, 20);

        jLabel8.setText("Select Type");
        p_search.add(jLabel8);
        jLabel8.setBounds(30, 110, 90, 20);

        buttonGroup1.add(rb_Note1);
        rb_Note1.setText("Notes");
        p_search.add(rb_Note1);
        rb_Note1.setBounds(150, 110, 80, 23);

        buttonGroup1.add(rb_Paper1);
        rb_Paper1.setText("Papers");
        p_search.add(rb_Paper1);
        rb_Paper1.setBounds(250, 110, 90, 23);

        bt_search.setText("Search");
        bt_search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_searchActionPerformed(evt);
            }
        });
        p_search.add(bt_search);
        bt_search.setBounds(150, 170, 80, 23);

        sp_search.setBackground(new java.awt.Color(204, 255, 204));

        mainpanel.setBackground(new java.awt.Color(255, 255, 255));
        mainpanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        mainpanel.setLayout(null);
        sp_search.setViewportView(mainpanel);

        p_search.add(sp_search);
        sp_search.setBounds(0, 210, 360, 480);

        jPanel1.add(p_search);
        p_search.setBounds(310, 0, 360, 690);

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel6.setLayout(null);

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel10.setText("RECENT PAPERS");
        jPanel6.add(jLabel10);
        jLabel10.setBounds(80, 10, 120, 30);

        spRecentNotes1.setBackground(new java.awt.Color(255, 255, 255));
        spRecentNotes1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        spPanel1.setBackground(new java.awt.Color(255, 255, 255));
        spPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        javax.swing.GroupLayout spPanel1Layout = new javax.swing.GroupLayout(spPanel1);
        spPanel1.setLayout(spPanel1Layout);
        spPanel1Layout.setHorizontalGroup(
            spPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 308, Short.MAX_VALUE)
        );
        spPanel1Layout.setVerticalGroup(
            spPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 749, Short.MAX_VALUE)
        );

        spRecentNotes1.setViewportView(spPanel1);

        jPanel6.add(spRecentNotes1);
        spRecentNotes1.setBounds(0, 100, 320, 590);

        jPanel1.add(jPanel6);
        jPanel6.setBounds(670, 0, 320, 690);

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel4.setLayout(null);

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel9.setText("RECENT NOTES");
        jPanel4.add(jLabel9);
        jLabel9.setBounds(80, 10, 120, 30);

        spRecentNotes.setBackground(new java.awt.Color(255, 255, 255));
        spRecentNotes.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        spPanel.setBackground(new java.awt.Color(255, 255, 255));
        spPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        javax.swing.GroupLayout spPanelLayout = new javax.swing.GroupLayout(spPanel);
        spPanel.setLayout(spPanelLayout);
        spPanelLayout.setHorizontalGroup(
            spPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 308, Short.MAX_VALUE)
        );
        spPanelLayout.setVerticalGroup(
            spPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 749, Short.MAX_VALUE)
        );

        spRecentNotes.setViewportView(spPanel);

        jPanel4.add(spRecentNotes);
        spRecentNotes.setBounds(0, 100, 310, 670);

        jPanel1.add(jPanel4);
        jPanel4.setBounds(0, 0, 310, 690);

        tb.addTab("Home", jPanel1);

        jPanel2.setLayout(null);

        Myupload.setBackground(new java.awt.Color(204, 255, 255));
        Myupload.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Myupload.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("UPLOAD NEW PAPER");
        Myupload.add(jLabel1);
        jLabel1.setBounds(190, 20, 150, 30);

        jLabel2.setText("SELECT SUBJECT CODE");
        Myupload.add(jLabel2);
        jLabel2.setBounds(20, 130, 130, 20);

        jLabel3.setText("Select File Path");
        Myupload.add(jLabel3);
        jLabel3.setBounds(20, 390, 110, 20);

        cb_semester.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select", "1", "2", "3", "4", "5", "6", "7", "8", " " }));
        cb_semester.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cb_semesterItemStateChanged(evt);
            }
        });
        Myupload.add(cb_semester);
        cb_semester.setBounds(220, 80, 130, 20);

        cb_subcode.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select" }));
        Myupload.add(cb_subcode);
        cb_subcode.setBounds(220, 130, 130, 20);

        lb_title.setText("Enter Title");
        Myupload.add(lb_title);
        lb_title.setBounds(20, 170, 100, 20);

        lb_Discription.setText("Enter Discription");
        Myupload.add(lb_Discription);
        lb_Discription.setBounds(20, 200, 120, 30);
        Myupload.add(tf_title);
        tf_title.setBounds(220, 170, 140, 20);

        ta_discription.setColumns(20);
        ta_discription.setRows(5);
        jScrollPane1.setViewportView(ta_discription);

        Myupload.add(jScrollPane1);
        jScrollPane1.setBounds(220, 210, 140, 60);

        jLabel6.setText("SELECT SEMESTER");
        Myupload.add(jLabel6);
        jLabel6.setBounds(20, 80, 130, 20);

        bg.add(rb_Note);
        rb_Note.setText("Notes");
        rb_Note.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rb_NoteItemStateChanged(evt);
            }
        });
        Myupload.add(rb_Note);
        rb_Note.setBounds(220, 300, 80, 23);

        bg.add(rb_Paper);
        rb_Paper.setText("Papers");
        rb_Paper.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rb_PaperItemStateChanged(evt);
            }
        });
        Myupload.add(rb_Paper);
        rb_Paper.setBounds(330, 300, 90, 23);

        lb_year.setText("Year Of Exam");
        Myupload.add(lb_year);
        lb_year.setBounds(20, 340, 100, 20);
        Myupload.add(tf_year);
        tf_year.setBounds(220, 340, 130, 20);

        jLabel4.setText("Select Type");
        Myupload.add(jLabel4);
        jLabel4.setBounds(20, 300, 100, 20);

        Add.setText("Add");
        Add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddActionPerformed(evt);
            }
        });
        Myupload.add(Add);
        Add.setBounds(210, 460, 100, 23);

        bt_browser.setText("Browser");
        bt_browser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_browserActionPerformed(evt);
            }
        });
        Myupload.add(bt_browser);
        bt_browser.setBounds(220, 390, 90, 23);

        jPanel2.add(Myupload);
        Myupload.setBounds(470, 0, 510, 680);

        jPanel5.setBackground(new java.awt.Color(153, 204, 255));
        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setText("My UPLOADS");

        jt.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jt);

        bt_Delete.setText("DELETE");
        bt_Delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_DeleteActionPerformed(evt);
            }
        });

        bt_cancel.setText("CANCEL");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addContainerGap(16, Short.MAX_VALUE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(176, 176, 176)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(90, 90, 90)
                .addComponent(bt_Delete, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(bt_cancel, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(72, 72, 72))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(143, 143, 143)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bt_Delete)
                    .addComponent(bt_cancel))
                .addContainerGap(120, Short.MAX_VALUE))
        );

        jPanel2.add(jPanel5);
        jPanel5.setBounds(-10, 0, 480, 570);

        tb.addTab("My Uploads", jPanel2);

        p_Setting.setLayout(null);

        password.setText("Change Password");
        password.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passwordActionPerformed(evt);
            }
        });
        p_Setting.add(password);
        password.setBounds(381, 263, 140, 40);

        lb1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        p_Setting.add(lb1);
        lb1.setBounds(297, 22, 300, 50);

        tb.addTab("Settings", p_Setting);

        getContentPane().add(tb);
        tb.setBounds(0, 20, 1000, 720);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void passwordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passwordActionPerformed
        new StudentChangePassword(rollno);
    }//GEN-LAST:event_passwordActionPerformed

    private void cb_semesterItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cb_semesterItemStateChanged
         s = (String) cb_semester.getSelectedItem();
        request = "getsubject\r\n";
        new Thread(new Client()).start();
    }//GEN-LAST:event_cb_semesterItemStateChanged

    private void rb_NoteItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_rb_NoteItemStateChanged
        lb_year.setVisible(false);
        tf_year.setVisible(false);
    }//GEN-LAST:event_rb_NoteItemStateChanged

    private void rb_PaperItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_rb_PaperItemStateChanged
        lb_year.setVisible(true);
        tf_year.setVisible(true);
    }//GEN-LAST:event_rb_PaperItemStateChanged

    private void bt_browserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_browserActionPerformed
        JFileChooser jfc = new JFileChooser("E:\\");
        int ans =jfc.showOpenDialog(this);
        if(ans==JFileChooser.APPROVE_OPTION)
        {
            path = jfc.getSelectedFile().getPath();
        }
    }//GEN-LAST:event_bt_browserActionPerformed

    private void AddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddActionPerformed
        request = "uploads";
        new Thread(new Client()).start();
    }//GEN-LAST:event_AddActionPerformed

    private void tbStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_tbStateChanged
        if(tb.getSelectedComponent()==jPanel2)
        {
            request="getmyuploads";
            new Thread(new Client()).start();
        }
        if(tb.getSelectedComponent()==jPanel1)
        {
            request="recentnotes";
            new Thread(new Client()).start();
            try
            {
                Thread.sleep(1500);
            }
            catch(Exception ex)
            {
                ex.printStackTrace();
            }
            request="recentpapers";
            new Thread(new Client()).start();
        }
    }//GEN-LAST:event_tbStateChanged

    private void bt_searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_searchActionPerformed
        request="searchpaper";
        new Thread(new Client()).start();
    }//GEN-LAST:event_bt_searchActionPerformed

    private void bt_DeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_DeleteActionPerformed
        request="delete";
        new Thread(new Client()).start();
    }//GEN-LAST:event_bt_DeleteActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Add;
    private javax.swing.JPanel Myupload;
    private javax.swing.ButtonGroup bg;
    private javax.swing.JButton bt_Delete;
    private javax.swing.JButton bt_browser;
    private javax.swing.JButton bt_cancel;
    private javax.swing.JButton bt_search;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> cb_semester;
    private javax.swing.JComboBox<String> cb_subcode;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jt;
    private javax.swing.JLabel lb1;
    private javax.swing.JLabel lb_Discription;
    private javax.swing.JLabel lb_title;
    private javax.swing.JLabel lb_title1;
    private javax.swing.JLabel lb_year;
    private javax.swing.JPanel mainpanel;
    private javax.swing.JPanel p_Setting;
    private javax.swing.JPanel p_search;
    private javax.swing.JButton password;
    private javax.swing.JRadioButton rb_Note;
    private javax.swing.JRadioButton rb_Note1;
    private javax.swing.JRadioButton rb_Paper;
    private javax.swing.JRadioButton rb_Paper1;
    private javax.swing.JPanel spPanel;
    private javax.swing.JPanel spPanel1;
    private javax.swing.JScrollPane spRecentNotes;
    private javax.swing.JScrollPane spRecentNotes1;
    private javax.swing.JScrollPane sp_search;
    private javax.swing.JTextArea ta_discription;
    private javax.swing.JTabbedPane tb;
    private javax.swing.JTextField tf_search;
    private javax.swing.JTextField tf_title;
    private javax.swing.JTextField tf_year;
    // End of variables declaration//GEN-END:variables
   class Mymodel extends AbstractTableModel
    {
        String title[] = {"Title","Description","Date","Type","Paper Id"};
        public String getColumnName(int index)
        {
            return title[index];
        }
        public int getColumnCount()
        {
            return 5;
        }
        public int getRowCount()
        {
            return al.size();
        }
        public Object getValueAt(int row, int col)
        {
            Papers p= al.get(row);
            if(col==0)
                return p.title ;
            else if(col==1)
                return p.description;
            else if(col==2)
                return p.date;
            else if(col==3)
                return p.type;
            else
                return p.paperid;
        }
    }
    public class Client implements Runnable {
        
        Socket sock;
        DataOutputStream dos;
        DataInputStream dis;
        
        Client() {
        }
        
        public void run() {
            String res;
            try {
                System.out.println("Client Request Send");
                sock = new Socket("127.0.0.1", 9999);
                System.out.println("Request Accepted by Server");
                dos = new DataOutputStream(sock.getOutputStream());
                dis = new DataInputStream(sock.getInputStream());
                System.out.println("Stream Connected");
                if (request.equals("getsubject\r\n")) {
                    try {
                        dos.writeBytes(request);
                        dos.writeBytes(s + "\r\n");
                        dos.writeBytes(rollno + "\r\n");
                        cb_subcode.removeAllItems();
                        while(true)
                        {
                            String s1=dis.readLine();
                            if(s1.equals("end"))
                            {
                                break;
                            }
                            cb_subcode.addItem(s1);
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
                else if(request.equals("uploads"))
                {
                    
                    
                    String s1=(String)cb_semester.getSelectedItem();
                    String s2=(String)cb_subcode.getSelectedItem();
                    String s3=tf_title.getText();
                    String s4=ta_discription.getText();
                    String s5=tf_year.getText();
                    File f = new File(path);
                    String name=f.getName();
                    long len=f.length();
                    String s7=null;
                    if(rb_Note.isSelected())
                    {
                        s7="Note\r\n";
                    }
                    else
                    {
                    s7="Paper\r\n";
                    }
                    System.out.println(s1);
                    System.out.println(s2);
                    System.out.println(s3);
                    System.out.println(s4);
                    System.out.println(s5);
                    System.out.println(s7);
                    System.out.println(name);
                    System.out.println(len);
                    
                    dos.writeBytes(request+"\r\n");
                    dos.writeBytes(s1+"\r\n");
                    dos.writeBytes(s2+"\r\n");
                    dos.writeBytes(s3+"\r\n");
                    dos.writeBytes(s4+"\r\n");
                    dos.writeBytes(s5+"\r\n");
                    dos.writeBytes(s7);
                    //File
                    dos.writeBytes(name+"\r\n");
                    dos.writeLong(len);
                    dos.writeBytes(rollno+"\r\n");
                    int count=0;
                    fis= new FileInputStream(path); 
                    byte[]b= new byte[10000];
                    while(true)
                    {
                        int x=fis.read(b,0,1000);
                        count = count+x;
                        dos.write(b,0,x);
                        if(count==len)
                        break;
                    }
                    if(dis.readLine().equals("Success"))
                    {
                        JOptionPane.showMessageDialog(StudentHome.this, "Successfully Done");
                        al.clear();
                        request="getmyuploads";
                        new Thread(new Client()).start();
                    }
                    else
                    JOptionPane.showMessageDialog(StudentHome.this, "Failed");
                }
                else if(request.equals("getmyuploads"))
                {
                    al.clear();
                    dos.writeBytes("getmyuploads\r\n");
                    dos.writeBytes(rollno+"\r\n");
                    while(true)
                    {
                        String title=dis.readLine();
                        if(title.equals("end"))
                        {
                            break;
                        }
                        String Description=dis.readLine();
                        String Date=dis.readLine();
                        String type=dis.readLine();
                        String paperid=dis.readLine();
                        al.add(new Papers(title,Description,Date,type,paperid));
                    }
                    ptm.fireTableDataChanged();
                }
                else if(request.equals("searchpaper"))
                {
                    String title1;
                    String Description;
                    String uploadedby;
                    String paperid;
                    ArrayList <Paper_Search> al1= new ArrayList<>();
                    dos.writeBytes("searchpaper\r\n");
                    String title=tf_search.getText();
                    String type=null;
                    if(rb_Note1.isSelected())
                    {
                        type="Note";
                    }
                    else
                    {
                    type="Paper";
                    }
                    dos.writeBytes(title+"\r\n");
                    dos.writeBytes(type+"\r\n"); 
                    
                    while(true)
                    {
                        title1=dis.readLine();
                        System.out.println(title1);
                        if(title1.equals("end"))
                        {
                            break;
                        }
                        Description=dis.readLine();
                        uploadedby=dis.readLine();
                        paperid=dis.readLine();
                        System.out.println(paperid);
                        al1.add(new Paper_Search(title1,Description,paperid,uploadedby));
                    }
                    mainpanel.removeAll();
                    mainpanel.repaint();
                    Panel_Paper sp[]=new Panel_Paper[al1.size()];
                    mainpanel.setPreferredSize(new Dimension(420,2000));
                    int y=10;
                    for(int i=0;i<al1.size();i++)
                    {
                        String pid = al1.get(i).paperid;
                        String b1=al1.get(i).title;
                        String b2=al1.get(i).description;
                        String b3=al1.get(i).uploadedby;
                        sp[i]=new Panel_Paper();
                        sp[i].lb_Title1.setText(b1);
                        sp[i].lb_Upload.setText(b3);
                        sp[i].lb_Description.setText(b2);
                        sp[i].setBounds(10, y, 420,200);
                        sp[i].addMouseListener(new MouseAdapter()
                        {
                            public void mouseClicked(MouseEvent e)
                            {
                                if(e.getClickCount()==2)
                                {
                                    System.out.println(pid);
                                    new PanelDetail(pid).setVisible(true);
                                }
                            }
                        });
                        mainpanel.add(sp[i]);
                        mainpanel.repaint();
                        y=y+210;
                    }
                }
                else if(request.equals("recentnotes"))
                {
                    System.out.println("in else if");
                    String title1;
                    String Description;
                    String uploadedby;
                    String paperid;
                    ArrayList <Paper_Search> alRecent1= new ArrayList<>();
                    dos.writeBytes("recentnotes\r\n");
                    while(true)
                    {
                        title1=dis.readLine();
                        System.out.println(title1);
                        if(title1.equals("end"))
                        {
                            break;
                        }
                        Description=dis.readLine();
                        uploadedby=dis.readLine();
                        paperid=dis.readLine();
                        System.out.println(paperid);
                        alRecent1.add(new Paper_Search(title1,Description,paperid,uploadedby));
                    }
                    spPanel.removeAll();
                    spPanel.repaint();
                    Panel_Paper sp[]=new Panel_Paper[alRecent1.size()];
                    spPanel.setPreferredSize(new Dimension(420,2000));
                    int y=10;
                    for(int i=0;i<alRecent1.size();i++)
                    {
                        String pid=alRecent1.get(i).paperid;
                        String b1=alRecent1.get(i).title;
                        String b2=alRecent1.get(i).description;
                        String b3=alRecent1.get(i).uploadedby;
                        sp[i]=new Panel_Paper();
                        sp[i].lb_Title1.setText(b1);
                        sp[i].lb_Upload.setText(b3);
                        sp[i].lb_Description.setText(b2);
                        sp[i].setBounds(10, y, 310,200);
                        sp[i].addMouseListener(new MouseAdapter()
                        {
                            public void mouseClicked(MouseEvent e)
                            {
                                if(e.getClickCount()==2)
                                {
                                    System.out.println(pid);
                                    new PanelDetail(pid).setVisible(true);
                                }
                            }
                        });
                        spPanel.add(sp[i]);
                        spPanel.repaint();
                        y=y+210;
                    }
                }
                else if(request.equals("recentpapers"))
                {
                    System.out.println("in else if");
                    String title1;
                    String Description;
                    String uploadedby;
                    String paperid;
                    ArrayList <Paper_Search> alRecent2= new ArrayList<>();
                    dos.writeBytes("recentpapers\r\n");
                    while(true)
                    {
                        title1=dis.readLine();
                        System.out.println(title1);
                        if(title1.equals("end"))
                        {
                            break;
                        }
                        Description=dis.readLine();
                        uploadedby=dis.readLine();
                        paperid=dis.readLine();
                        System.out.println(paperid);
                        alRecent2.add(new Paper_Search(title1,Description,paperid,uploadedby));
                    }
                    spPanel1.removeAll();
                    spPanel1.repaint();
                    Panel_Paper sp[]=new Panel_Paper[alRecent2.size()];
                    spPanel1.setPreferredSize(new Dimension(420,2000));
                    int y=10;
                    for(int i=0;i<alRecent2.size();i++)
                    {
                        String pid=alRecent2.get(i).paperid;
                        String b1=alRecent2.get(i).title;
                        String b2=alRecent2.get(i).description;
                        String b3=alRecent2.get(i).uploadedby;
                        sp[i]=new Panel_Paper();
                        sp[i].lb_Title1.setText(b1);
                        sp[i].lb_Upload.setText(b3);
                        sp[i].lb_Description.setText(b2);
                        sp[i].setBounds(10, y, 310,200);
                        sp[i].addMouseListener(new MouseAdapter()
                        {
                            public void mouseClicked(MouseEvent e)
                            {
                                if(e.getClickCount()==2)
                                {
                                    System.out.println(pid);
                                    new PanelDetail(pid).setVisible(true);
                                }
                            }
                        });
                        spPanel1.add(sp[i]);
                        spPanel1.repaint();
                        y=y+210;
                    }
                }
                else if(request.equals("delete"))
                {
                    dos.writeBytes("delete\r\n");
                    String pid;
                    int index = jt.getSelectedRow();
                    if(index==-1)
                    {
                         JOptionPane.showMessageDialog(StudentHome.this, "Please Select a row!!");
                    }
                    else
                    {
                        pid = al.get(index).paperid;
                        System.out.println(pid);
                        dos.writeBytes(pid+"\r\n");
                        
                        String s=dis.readLine();
                        if(s.equals("success"))
                        {
                            JOptionPane.showMessageDialog(StudentHome.this, "Deleted Successfully");
                            request="getmyuploads";
                            new Thread(new Client()).start();
                        }
                    }
                }
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        
    }
    
}
