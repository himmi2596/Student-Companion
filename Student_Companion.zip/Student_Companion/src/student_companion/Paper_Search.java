package student_companion;
public class Paper_Search 
{
    String title;
    String description;
    String paperid;
    String uploadedby;
    public Paper_Search(String title,String description,String paperid,String uploadedby)
    {
        this.title=title;
        this.description=description;
        this.paperid=paperid;
        this.uploadedby=uploadedby;
    }
    public void show()
    {
        System.out.println(title);
        System.out.println(description);
        System.out.println(paperid);
        System.out.println(uploadedby);
    }
}

