package student_companion;
public class Subject
{
    String Subject_Name,Subject_Code;
    public Subject(String Subject_Name,String Subject_Code)
    {
        this.Subject_Code = Subject_Code;
        this.Subject_Name = Subject_Name;
    }
    public Subject()
    {
    }
}
