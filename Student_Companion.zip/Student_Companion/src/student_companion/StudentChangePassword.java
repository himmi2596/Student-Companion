package student_companion;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.*;
import javax.swing.JOptionPane;

public class StudentChangePassword extends javax.swing.JFrame {

    String request, res,rollno;
    String s1,s2,s3,s4;
    public StudentChangePassword(String rollno) {
        initComponents();
        this.rollno=rollno;
        tf_rollno.setText(rollno);
        tf_rollno.setEditable(false);
        this.setSize(500, 500);
        this.setVisible(true);
        this.setDefaultCloseOperation(2);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        change = new javax.swing.JButton();
        tf_rollno = new javax.swing.JTextField();
        tf_OldPassword = new javax.swing.JPasswordField();
        tf_ConfirmPassword = new javax.swing.JPasswordField();
        tf_NewPassword = new javax.swing.JPasswordField();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setText("NEW PASSWORD");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(33, 214, 100, 41);

        jLabel2.setText("YOUR ROLLNO");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(31, 70, 100, 41);

        jLabel3.setText("CONFIRM PASSWORD");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(33, 286, 116, 41);

        jLabel4.setText("OLD PASSWORD");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(33, 146, 100, 41);

        change.setText("Change");
        change.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                changeActionPerformed(evt);
            }
        });
        getContentPane().add(change);
        change.setBounds(160, 400, 150, 23);
        getContentPane().add(tf_rollno);
        tf_rollno.setBounds(170, 78, 150, 20);
        getContentPane().add(tf_OldPassword);
        tf_OldPassword.setBounds(170, 156, 150, 20);
        getContentPane().add(tf_ConfirmPassword);
        tf_ConfirmPassword.setBounds(167, 296, 151, 20);
        getContentPane().add(tf_NewPassword);
        tf_NewPassword.setBounds(170, 214, 150, 20);

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel5.setText("CHANGE PASSWORD");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(100, 10, 260, 30);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void changeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_changeActionPerformed
         s1 = tf_rollno.getText();
         s2 = tf_OldPassword.getText();
         s3 = tf_NewPassword.getText();
         s4 = tf_ConfirmPassword.getText();
        if (s1.isEmpty() || s2.isEmpty()
                || s3.isEmpty() || s4.isEmpty()) {
            JOptionPane.showMessageDialog(StudentChangePassword.this, "All Fields are Required!!");
        } else if (s3.equals(s4)) {
            request = "changePassword";
            new Thread(new Client()).start();

        } else {
            JOptionPane.showMessageDialog(StudentChangePassword.this, "New and confirm password must match!!");
            tf_NewPassword.setText("");
            tf_ConfirmPassword.setText("");
        }
    }//GEN-LAST:event_changeActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton change;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPasswordField tf_ConfirmPassword;
    private javax.swing.JPasswordField tf_NewPassword;
    private javax.swing.JPasswordField tf_OldPassword;
    private javax.swing.JTextField tf_rollno;
    // End of variables declaration//GEN-END:variables

    public class Client implements Runnable {

        Socket sock;
        DataOutputStream dos;
        DataInputStream dis;

        Client() {
        }

        public void run() {
            String res;
            try {
                System.out.println("Client Request Send");
                sock = new Socket("127.0.0.1", 9999);
                System.out.println("Request Accepted by Server");
                dos = new DataOutputStream(sock.getOutputStream());
                dis = new DataInputStream(sock.getInputStream());
                System.out.println("Stream Connected");
                System.out.println(request);
                if(request.equals("changePassword")) 
                {
                    try {
                        dos.writeBytes(request+"\r\n");
                        dos.writeBytes(s1+"\r\n");
                        dos.writeBytes(s2+"\r\n");
                        dos.writeBytes(s3+"\r\n");
                        res =dis.readLine();
                        if (res.equals("success")) 
                        {
                            JOptionPane.showMessageDialog(StudentChangePassword.this, "Password Changed Successful!!");
                        } else 
                        {
                            JOptionPane.showMessageDialog(StudentChangePassword.this, "Password is wrong!!");
                            tf_OldPassword.setText("");
                            tf_NewPassword.setText("");
                            tf_ConfirmPassword.setText("");
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            }

        
        catch(Exception ex)
            {
                ex.printStackTrace();
        }
    }

}
}
