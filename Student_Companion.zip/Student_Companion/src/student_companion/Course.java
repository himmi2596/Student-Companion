package student_companion;
public class Course
{
    String Course_Name,Description;
    public Course(String Course_Name,String Description)
    {
        this.Course_Name = Course_Name;
        this.Description = Description;
    }
    public Course()
    {
    }
}
