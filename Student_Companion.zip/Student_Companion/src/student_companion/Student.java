package student_companion;
public class Student 
{
    String name;
    String rollno;
    String email;
    String phoneNumber;
    String gender;
    Student(String name,String rollno,String email,String phone_number,String gender)
    {
        this.name= name;
        this.rollno=rollno;
        this.email=email;
        this.phoneNumber=phoneNumber;
        this.gender=gender;
    }
    Student()
    {
        
    }
}
