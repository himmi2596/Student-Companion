package student_companion;
public class Papers 
{
    String title;
    String description;
    String date;
    String type;
    String paperid;
    public Papers()
    {
        
    }
    public Papers(String title,String Description,String Date,String type,String paperid)
    {
        this.title=title;
        this.date=Date;
        this.type=type;
        this.description=Description;
        this.paperid=paperid;
    }
}
