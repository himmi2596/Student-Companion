package student_companion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class Add_Course extends javax.swing.JInternalFrame 
{
    public Add_Course() 
    {
        initComponents();
        this.setSize(500,500);
        this.setVisible(true);
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver loading");
            Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student_companion", "root", "system");
            System.out.println("connection built");
            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stmt.executeQuery("select * from department");
            cb.addItem("Select");
            while(rs.next())
            {
                String d=rs.getString("Department_Name");
                cb.addItem(d);
            }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        cb = new javax.swing.JComboBox<>();
        courseName = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        description = new javax.swing.JTextArea();
        add = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setText("  SELECT DEPARTMENT");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(10, 119, 141, 55);

        jLabel2.setText("   ENTER COURSE NAME");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(10, 221, 124, 37);

        jLabel3.setText("   DESCRIPTION");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(10, 328, 124, 37);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel4.setText("ADD COURSE");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(157, 0, 209, 115);

        getContentPane().add(cb);
        cb.setBounds(181, 125, 166, 43);
        getContentPane().add(courseName);
        courseName.setBounds(181, 220, 166, 39);

        description.setColumns(20);
        description.setRows(5);
        jScrollPane1.setViewportView(description);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(181, 328, 166, 96);

        add.setText("ADD");
        add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addActionPerformed(evt);
            }
        });
        getContentPane().add(add);
        add.setBounds(200, 442, 96, 42);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addActionPerformed
        String s=(String)cb.getSelectedItem();
        if(s.equals("Select"))
        {
            JOptionPane.showMessageDialog(Add_Course.this, "Please Select the Department!!");
        }
        else
        {
            if(courseName.getText().isEmpty() || description.getText().isEmpty())
            {
                JOptionPane.showMessageDialog(Add_Course.this, "All Fields are Required!!");
                courseName.setText("");
                description.setText("");
            }
            else
            {
                String s1=courseName.getText();
                String s2=description.getText();
                try
                {
                    Class.forName("com.mysql.jdbc.Driver");
                    System.out.println("Driver loading");
                    Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student_companion", "root", "system");
                    System.out.println("connection built");
                    Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                    ResultSet rs = stmt.executeQuery("select * from course where Course_Name = '"+s1+"'");
                    if(rs.next())
                    {
                        JOptionPane.showMessageDialog(Add_Course.this, "Already Exists");   
                    }
                    else
                    {
                        rs.moveToInsertRow();
                        rs.updateString("Course_Name",s1);
                        System.out.println("Done1");
                        rs.updateString("Department", s);
                        System.out.println("Done2");
                        rs.updateString("Description",s2);
                        System.out.println("Done3");
                        rs.insertRow();
                        JOptionPane.showMessageDialog(Add_Course.this, "Task Complete");
                    }
                }
                catch(Exception ex)
                {
                    ex.printStackTrace();
                }
            }
        }
    }//GEN-LAST:event_addActionPerformed

    public static void main(String args[]) 
    {
        java.awt.EventQueue.invokeLater(new Runnable() 
        {
            public void run() 
            {
                new Add_Course().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton add;
    private javax.swing.JComboBox<String> cb;
    private javax.swing.JTextField courseName;
    private javax.swing.JTextArea description;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
