package student_companion;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;
public class ViewAllCourse extends javax.swing.JInternalFrame 
{
    ArrayList <Course> al;
    Mymodel ctm;
    public ViewAllCourse() 
    {
        initComponents();
        al = new ArrayList<>();
        ctm = new Mymodel();
        jt.setModel(ctm);
        this.setSize(500,500);
        this.setVisible(true);
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver loading");
            Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student_companion", "root", "system");
            System.out.println("connection built");
            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stmt.executeQuery("select * from department");
            cb.addItem("Select");
            System.out.println("Done1");
            while(rs.next())
            {
                String d=rs.getString("Department_Name");
                cb.addItem(d);
            }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
    public class Mymodel extends AbstractTableModel
    {
        String title[] = {"COURSE","DESCRIPTION"};
        public String getColumnName(int index)
        {
            return title[index];
        }
        public int getColumnCount()
        {
            return 2;
        }
        public int getRowCount()
        {
            return al.size();
        }
        public Object getValueAt(int row, int col)
        {
            Course c= al.get(row);
            if(col==0)
                return c.Course_Name ;
            else
                return c.Description;
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        cb = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        jt = new javax.swing.JTable();
        delete = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("VIEW ALL COURSES");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(130, 20, 250, 40);

        jLabel2.setText("Select Department");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(50, 130, 110, 30);

        cb.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbItemStateChanged(evt);
            }
        });
        getContentPane().add(cb);
        cb.setBounds(220, 140, 110, 20);

        jt.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jt);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(40, 250, 370, 160);

        delete.setText("DELETE");
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });
        getContentPane().add(delete);
        delete.setBounds(190, 450, 90, 30);

        pack();
    }// </editor-fold>//GEN-END:initComponents
    public void fetchData()
    {
        al.clear();
        try
        {
            String crs =(String)cb.getSelectedItem();
            if(crs.equals("Select"))
            {
                JOptionPane.showMessageDialog(ViewAllCourse.this, "Please Select the Department!!");
            }
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver loading");
            Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student_companion", "root", "system");
            System.out.println("connection built");
            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stmt.executeQuery("select * from course where Department ='"+crs+"'");
            System.out.println("Done1");
            while(rs.next())
            {
                Course c= new Course();
                c.Course_Name = rs.getString("Course_Name");
                c.Description = rs.getString("Description");
                al.add(c);
            }
            ctm.fireTableDataChanged();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
    private void cbItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbItemStateChanged
        fetchData();
    }//GEN-LAST:event_cbItemStateChanged

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
        String dt;
        int index = jt.getSelectedRow();
        if(index==-1)
        {
            System.out.println("Please Select row"); 
        }
        else
        {
            dt = al.get(index).Course_Name;
            System.out.println(dt);
            int flag = JOptionPane.showConfirmDialog(ViewAllCourse.this,"Are you Sure?");
            if(flag ==JOptionPane.YES_OPTION)
            {
                try
                {
                    Class.forName("com.mysql.jdbc.Driver");
                    System.out.println("Driver loading");
                    Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student_companion", "root", "system");
                    System.out.println("connection built");
                    Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                    ResultSet rs = stmt.executeQuery("select * from course where Course_Name = '"+dt+"'");
                    if(rs.next())
                    {
                        rs.deleteRow();
                        JOptionPane.showMessageDialog(ViewAllCourse.this, "Delete Successfully");
                        ViewAllCourse.this.fetchData();
                    }
                }
                catch(Exception ex)
                {
                    ex.printStackTrace();
                }
            }
        }
    }//GEN-LAST:event_deleteActionPerformed

    public static void main(String args[]) 
    {

        java.awt.EventQueue.invokeLater(new Runnable() 
        {
            public void run() 
            {
                new ViewAllCourse().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cb;
    private javax.swing.JButton delete;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jt;
    // End of variables declaration//GEN-END:variables
}
