package student_companion;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class AdminHome extends javax.swing.JFrame 
{
    Dimension d;
    int w,h;
    String username;
    String rollno,password;
    public AdminHome(String username) 
    {
        this.username = username;
        initComponents();
        d = Toolkit.getDefaultToolkit().getScreenSize();
        w = d.width;
        h = d.height;
        this.setSize(d);
        jDesktopPane1.setSize(w-10,h-100);
        this.add(jDesktopPane1);
        this.setDefaultCloseOperation(2);
        new Thread(new Server()).start();
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuItem1 = new javax.swing.JMenuItem();
        jDesktopPane1 = new javax.swing.JDesktopPane();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        menu_Department = new javax.swing.JMenuItem();
        menu_Courses = new javax.swing.JMenuItem();
        menu_Subject = new javax.swing.JMenuItem();
        menu_Student = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        View_Department = new javax.swing.JMenuItem();
        View_Courses = new javax.swing.JMenuItem();
        View_Subject = new javax.swing.JMenuItem();
        Change_Password = new javax.swing.JMenu();
        menu_password = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();

        jMenuItem1.setText("jMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);
        getContentPane().add(jDesktopPane1);
        jDesktopPane1.setBounds(0, 0, 500, 460);

        jMenu1.setText("ADD");

        menu_Department.setText("ADD DEPARTMENT");
        menu_Department.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menu_DepartmentActionPerformed(evt);
            }
        });
        jMenu1.add(menu_Department);

        menu_Courses.setText("ADD COURSES");
        menu_Courses.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menu_CoursesActionPerformed(evt);
            }
        });
        jMenu1.add(menu_Courses);

        menu_Subject.setText("ADD SUBJECT");
        menu_Subject.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menu_SubjectActionPerformed(evt);
            }
        });
        jMenu1.add(menu_Subject);

        menu_Student.setText("ADD STUDENT");
        menu_Student.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menu_StudentActionPerformed(evt);
            }
        });
        jMenu1.add(menu_Student);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("VIEW");

        View_Department.setText("VIEW ALL DEPARTMENT");
        View_Department.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                View_DepartmentActionPerformed(evt);
            }
        });
        jMenu2.add(View_Department);

        View_Courses.setText("VIEW ALL COURSES");
        View_Courses.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                View_CoursesActionPerformed(evt);
            }
        });
        jMenu2.add(View_Courses);

        View_Subject.setText("VIEW ALL SUBJECT");
        View_Subject.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                View_SubjectActionPerformed(evt);
            }
        });
        jMenu2.add(View_Subject);

        jMenuBar1.add(jMenu2);

        Change_Password.setText("SETTINGS");

        menu_password.setText("CHANGE PASSWORD");
        menu_password.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menu_passwordActionPerformed(evt);
            }
        });
        Change_Password.add(menu_password);

        jMenuItem2.setText("LOGOUT");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        Change_Password.add(jMenuItem2);

        jMenuBar1.add(Change_Password);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void menu_CoursesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menu_CoursesActionPerformed
       Add_Course lf=new Add_Course();
        lf.setVisible(true);
        lf.setSize(w-10,h-100);
        lf.setResizable(true);
        lf.setIconifiable(true);
        lf.setMaximizable(true);
        lf.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        lf.setClosable(true);
        jDesktopPane1.add(lf);
    }//GEN-LAST:event_menu_CoursesActionPerformed

    private void menu_SubjectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menu_SubjectActionPerformed
        Add_Subject lf=new Add_Subject();
        lf.setVisible(true);
        lf.setSize(w-10,h-100);
        lf.setResizable(true);
        lf.setIconifiable(true);
        lf.setMaximizable(true);
        lf.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        lf.setClosable(true);
        jDesktopPane1.add(lf);
    }//GEN-LAST:event_menu_SubjectActionPerformed

    private void menu_StudentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menu_StudentActionPerformed
        Add_Student lf=new Add_Student();
        lf.setVisible(true);
        lf.setSize(w-10,h-100);
        lf.setResizable(true);
        lf.setIconifiable(true);
        lf.setMaximizable(true);
        lf.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        lf.setClosable(true);
        jDesktopPane1.add(lf);
    }//GEN-LAST:event_menu_StudentActionPerformed

    private void menu_DepartmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menu_DepartmentActionPerformed
        AddDepartment lf=new AddDepartment();
        lf.setVisible(true);
        lf.setSize(w-10,h-100);
        lf.setResizable(true);
        lf.setIconifiable(true);
        lf.setMaximizable(true);
        lf.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        lf.setClosable(true);
        jDesktopPane1.add(lf);
    }//GEN-LAST:event_menu_DepartmentActionPerformed

    private void View_DepartmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_View_DepartmentActionPerformed
        ViewAllDepartment lf=new ViewAllDepartment();
        lf.setVisible(true);
        lf.setSize(w-10,h-100);
        lf.setResizable(true);
        lf.setIconifiable(true);
        lf.setMaximizable(true);
        lf.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        lf.setClosable(true);
        jDesktopPane1.add(lf);
    }//GEN-LAST:event_View_DepartmentActionPerformed

    private void View_CoursesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_View_CoursesActionPerformed
        ViewAllCourse lf=new ViewAllCourse();
        lf.setVisible(true);
        lf.setSize(w-10,h-100);
        lf.setResizable(true);
        lf.setIconifiable(true);
        lf.setMaximizable(true);
        lf.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        lf.setClosable(true);
        jDesktopPane1.add(lf);
    }//GEN-LAST:event_View_CoursesActionPerformed

    private void View_SubjectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_View_SubjectActionPerformed
        ViewAllSubject lf=new ViewAllSubject();
        lf.setVisible(true);
        lf.setSize(w-10,h-100);
        lf.setResizable(true);
        lf.setIconifiable(true);
        lf.setMaximizable(true);
        lf.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        lf.setClosable(true);
        jDesktopPane1.add(lf);
    }//GEN-LAST:event_View_SubjectActionPerformed

    private void menu_passwordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menu_passwordActionPerformed
        AdminChangePassword lf=new AdminChangePassword(this.username);
        lf.setVisible(true);
        lf.setSize(w-10,h-100);
        lf.setResizable(true);
        lf.setIconifiable(true);
        lf.setMaximizable(true);
        lf.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        lf.setClosable(true);
        jDesktopPane1.add(lf);
    }//GEN-LAST:event_menu_passwordActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        JOptionPane.showMessageDialog(AdminHome.this, "All Fields are Required!!");
        new Admin_Login("qwit");
    }//GEN-LAST:event_jMenuItem2ActionPerformed
    public class Server implements Runnable  
{
    Socket sock;
    ServerSocket sersoc;
    Server()
    {
        try
        {
            sersoc = new ServerSocket(9999);
            System.out.println("Server ReaDy");
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
    public void run()
    {
        try
        {
            while(true)
            {
                sock=sersoc.accept();
            
                new Thread(new ClientHandler(sock)).start();
            }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
        
    }
    class ClientHandler implements Runnable
    {
        Socket sock;
        DataOutputStream dos;
        DataInputStream dis;
        FileOutputStream fos;
        FileInputStream fis;
        public void run()
        {
            try
            { 
                
                System.out.println("Client Request Accepted");
                dos = new DataOutputStream(sock.getOutputStream());
                dis = new DataInputStream(sock.getInputStream());
                System.out.println("Stream Connected");
                  
                String res = dis.readLine();
                if(res.equals("login"))
                {
                    rollno = dis.readLine();
                    password = dis.readLine();
                    
                    System.out.println(rollno);
                    System.out.println(password);
                    try
                    {
                        Class.forName("com.mysql.jdbc.Driver");
                        System.out.println("Driver loading");
                        Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student_companion", "root", "system");
                        System.out.println("connection built");
                        Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                        ResultSet rs = stmt.executeQuery("select * from student where Rollno = '"+rollno+"' and Password = '"+password+"'");
                        if(rs.next())
                        {
                            dos.writeBytes("success\r\n");
                        }
                        else
                        {
                            dos.writeBytes("failed\r\n");
                        }
                    }
                    catch(Exception ex)
                    {
                        ex.printStackTrace();
                    }
                }
                else if(res.equals("changePassword"))
                {
                    String rollno = dis.readLine();
                    String oldPassword = dis.readLine();
                    String newPassword = dis.readLine();
                    
                    
                    
                    System.out.println(rollno);
                    System.out.println(oldPassword);
                    System.out.println(newPassword);
                    try
                    {
                        Class.forName("com.mysql.jdbc.Driver");
                        System.out.println("Driver loading");
                        Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student_companion", "root", "system");
                        System.out.println("connection built");
                        Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                        ResultSet rs = stmt.executeQuery("select * from student where Rollno = '"+rollno+"' and Password = '"+oldPassword+"'");
                        if(rs.next())
                        {
                            rs.updateString("Password",newPassword);
                            rs.updateRow();
                            dos.writeBytes("success\r\n");
                        }
                        else
                        {
                            dos.writeBytes("failed\r\n");
                        }
                    }
                    catch(Exception ex)
                    {
                        ex.printStackTrace();
                    }
                }
                else if(res.equals("getsubject"))
                {
                    try
                    {
                        String semester = dis.readLine();
                        String rollno = dis.readLine();
                        String course="";
                        Class.forName("com.mysql.jdbc.Driver");
                        System.out.println("driver loading");
                        Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student_companion","root","system");
                        System.out.println("connection built");
                        Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
                        ResultSet rs = stmt.executeQuery("select * from student where Rollno = '"+rollno+"'");
                        if(rs.next())
                        {
                            course=rs.getString("Course_Name");
                        }
                        Statement stmt2 = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
                        ResultSet rs2 = stmt2.executeQuery("select * from subject where Semester ='"+semester+"' and Course_name='"+course+"' ");
                        while(rs2.next())
                        {
                            dos.writeBytes(rs2.getString("Subject_code")+"\r\n");
                        }
                        dos.writeBytes("end"+"\r\n");
                    }
                    catch(Exception ex)
                    {
                        ex.printStackTrace();
                    }
                }
                else if(res.equals("uploads"))
                {
                    String sem=dis.readLine();
                    String subcode=dis.readLine();
                    String title=dis.readLine();
                    String description=dis.readLine();
                    String year=dis.readLine();
                    String type=dis.readLine();
                    String name=dis.readLine();
                    long len = dis.readLong();
                    String rollno=dis.readLine();
                    
                    System.out.println(name+"--------------");
                    String path="E:\\study\\Java\\Server\\"+name;
                    int count=0;
                    fos= new FileOutputStream(path); 
                    byte[]b= new byte[10000];
                    while(true)
                    {
                        int x=dis.read(b,0,1000);
                        count = count+x;
                        fos.write(b,0,x);
                        if(count==len)
                        break;
                    }
                    fos.close();
                    try
                    {
                        Class.forName("com.mysql.jdbc.Driver");
                        System.out.println("Driver loading");
                        Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student_companion", "root", "system");
                        System.out.println("connection built");
                        Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                        ResultSet rs = stmt.executeQuery("select * from papers");
                        rs.moveToInsertRow();
                        rs.updateString("Title",title);
                        rs.updateString("Description",description);
                        rs.updateString("Subject_Code",subcode);
                        rs.updateString("Type",type);
                        rs.updateString("Semester",sem);
                        rs.updateString("Uploads_By",rollno);
                        rs.updateString("Year_Of_Examination",year);
                        rs.updateString("File_Path",path);
                        rs.insertRow();
                        dos.writeBytes("Success\r\n");
                    }
                    catch(Exception ex)
                    {
                        ex.printStackTrace();
                    }
                }
                else if(res.equals("getmyuploads"))
                {
                    String rollno=dis.readLine();
                   
                        Class.forName("com.mysql.jdbc.Driver");
                        System.out.println("Driver loading");
                        Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student_companion", "root", "system");
                        System.out.println("connection built");
                        Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                        ResultSet rs = stmt.executeQuery("select * from papers where Uploads_By = '"+rollno+"'");
                        while(rs.next())
                        {
                            dos.writeBytes(rs.getString("Title")+"\r\n");
                            dos.writeBytes(rs.getString("Description")+"\r\n");
                            dos.writeBytes(rs.getString("Date_Of_Upload")+"\r\n");
                            dos.writeBytes(rs.getString("Type")+"\r\n");
                            dos.writeBytes(rs.getString("Paperid")+"\r\n");
                        }
                        dos.writeBytes("end\r\n");
                }
                else if(res.equals("searchpaper"))
                {
                    String title=dis.readLine();
                    String type=dis.readLine();
                    Class.forName("com.mysql.jdbc.Driver");
                    System.out.println("Driver loading");
                    Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student_companion", "root", "system");
                    System.out.println("connection built");
                    Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                    ResultSet rs = stmt.executeQuery("select * from papers where Type = '"+type+"' and Title like '"+title+"%'");
                    while(rs.next())
                        {
                            dos.writeBytes(rs.getString("Title")+"\r\n");
                            System.out.println(rs.getString("Title"));
                            dos.writeBytes(rs.getString("Description")+"\r\n");
                            dos.writeBytes(rs.getString("Uploads_By")+"\r\n");
                            dos.writeBytes(rs.getString("Paperid")+"\r\n");
                        }
                        dos.writeBytes("end\r\n");
                }
                else if(res.equals("recentnotes"))
                {
                    Class.forName("com.mysql.jdbc.Driver");
                    System.out.println("Driver loading");
                    Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student_companion", "root", "system");
                    System.out.println("connection built");
                    Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                    ResultSet rs = stmt.executeQuery("select * from papers where Type ='Note' order by Date_Of_Upload desc");
                    while(rs.next())
                        {
                            dos.writeBytes(rs.getString("Title")+"\r\n");
                            System.out.println(rs.getString("Title"));
                            dos.writeBytes(rs.getString("Description")+"\r\n");
                            dos.writeBytes(rs.getString("Uploads_By")+"\r\n");
                            dos.writeBytes(rs.getString("Paperid")+"\r\n");
                        }
                        dos.writeBytes("end\r\n");
                }
                else if(res.equals("recentpapers"))
                {
                    Class.forName("com.mysql.jdbc.Driver");
                    System.out.println("Driver loading");
                    Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student_companion", "root", "system");
                    System.out.println("connection built");
                    Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                    ResultSet rs = stmt.executeQuery("select * from papers where Type ='Paper'order by Date_Of_Upload desc");
                    while(rs.next())
                        {
                            dos.writeBytes(rs.getString("Title")+"\r\n");
                            System.out.println(rs.getString("Title"));
                            dos.writeBytes(rs.getString("Description")+"\r\n");
                            dos.writeBytes(rs.getString("Uploads_By")+"\r\n");
                            dos.writeBytes(rs.getString("Paperid")+"\r\n");
                        }
                        dos.writeBytes("end\r\n");
                }
                else if(res.equals("getdetail"))
                    {
                        String pid=dis.readLine();
                        System.out.println(pid);
                        Class.forName("com.mysql.jdbc.Driver");
                        System.out.println("Driver loading");
                        Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student_companion", "root", "system");
                        System.out.println("connection built");
                        Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                        ResultSet rs = stmt.executeQuery("select * from papers where Paperid = '"+pid+"'");
                        if(rs.next())
                        {
                            dos.writeBytes(rs.getString("Title")+"\r\n");
                            dos.writeBytes(rs.getString("Description")+"\r\n");
                            dos.writeBytes(rs.getString("Subject_Code")+"\r\n");
                            dos.writeBytes(rs.getString("Type")+"\r\n");
                            dos.writeBytes(rs.getString("Semester")+"\r\n");
                            dos.writeBytes(rs.getString("year_Of_Examination")+"\r\n");
                            dos.writeBytes(rs.getString("Date_Of_Upload")+"\r\n");
                            dos.writeBytes(rs.getString("Uploads_By")+"\r\n");
                            dos.writeBytes(rs.getString("File_Path")+"\r\n");
                        }
                    }
                else if(res.equals("delete"))
                {
                    String pid = dis.readLine();
                    System.out.println(pid);
                    Class.forName("com.mysql.jdbc.Driver");
                    System.out.println("Driver loading");
                    Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student_companion", "root", "system");
                    System.out.println("connection built");
                    Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                    ResultSet rs = stmt.executeQuery("select * from papers where Paperid = '"+pid+"'");
                    if(rs.next())
                    {
                        rs.deleteRow();
                        dos.writeBytes("success\r\n");
                    }
                }
                else if(res.equals("download"))
                {
                    File f = new File(dis.readLine());
                    fis = new FileInputStream(f);
                    dos.writeBytes(f.getName()+"\r\n");
                    System.out.println(f.getName());
                    dos.writeLong(f.length());
                        
                    int count=0;
                    byte b[]= new byte[10000];
                    while(true)
                    {
                        int x=fis.read(b,0,10000);
                        count=count+x;
                        dos.write(b,0, x);
                        if(count==f.length())
                        break;
                    }
                }
                else if(res.equals("fetchpassword"))
                {
                    String email=dis.readLine();
                    Class.forName("com.mysql.jdbc.Driver");
                    System.out.println("Driver loading");
                    Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student_companion", "root", "system");
                    System.out.println("connection built");
                    Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                    ResultSet rs = stmt.executeQuery("select * from student where Email = '"+email+"'");
                    if(rs.next())
                    {
                        dos.writeBytes("success\r\n");
                        dos.writeBytes(rs.getString("Phone_Number")+"\r\n");
                        dos.writeBytes(rs.getString("Password")+"\r\n");
                    }
                    else
                    {
                        dos.writeBytes("fails\r\n");
                    }
                }
            }
            catch(Exception ex)
            {
                ex.printStackTrace();
            }
        }
        ClientHandler(Socket sock)
        {
            this.sock=sock;
        }
    }
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu Change_Password;
    private javax.swing.JMenuItem View_Courses;
    private javax.swing.JMenuItem View_Department;
    private javax.swing.JMenuItem View_Subject;
    private javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem menu_Courses;
    private javax.swing.JMenuItem menu_Department;
    private javax.swing.JMenuItem menu_Student;
    private javax.swing.JMenuItem menu_Subject;
    private javax.swing.JMenuItem menu_password;
    // End of variables declaration//GEN-END:variables
}
