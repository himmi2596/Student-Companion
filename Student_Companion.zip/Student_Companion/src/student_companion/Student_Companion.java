package student_companion;
public class Student_Companion
{
    
    public static void main(String[] args) 
    {
        
    }
    
}
