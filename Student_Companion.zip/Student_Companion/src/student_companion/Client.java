package student_companion;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Client 
{
    Socket sock;
    DataOutputStream dos;
    DataInputStream dis;
    Client()
    {
        try
        {
            System.out.println("Client Request Send");
            sock = new Socket("127.0.0.1",9999);
            System.out.println("Request Accepted by Server");
            dos = new DataOutputStream(sock.getOutputStream());
            dis = new DataInputStream(sock.getInputStream());
            System.out.println("Stream Connected");
            dos.writeBytes("Hello Server I am Your Client\r\n");
            
            System.out.println("Server:"+dis.readLine());
            
            System.out.println("Done");
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
    
    public static void main(String[] args) 
    {
        Client obj = new Client();
    }
}
