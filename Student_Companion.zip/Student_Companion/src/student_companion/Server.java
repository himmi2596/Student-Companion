package student_companion;
import java.io.*;
import java.net.*;
public class Server 
{
    Socket sock;
    ServerSocket sersoc;
    Server()
    {
        try
        {
            sersoc = new ServerSocket(9999);
            System.out.println("Server ReaDy");
            while(true)
            {
                sock=sersoc.accept();
            
                new Thread(new ClientHandler(sock)).start();
           }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
    class ClientHandler implements Runnable
    {
        Socket sock;
        DataOutputStream dos;
        DataInputStream dis;
        public void run()
        {
            try
            {
                System.out.println("Client Request Accepted");
                dos = new DataOutputStream(sock.getOutputStream());
                dis = new DataInputStream(sock.getInputStream());
                System.out.println("Stream Connected");
            
            
                System.out.println("Client:"+dis.readLine());
                System.out.println("Client:"+dis.readLine());
                System.out.println("Client:"+dis.readLine());
            
            
                dos.writeBytes("Hello Client!!\r\n");
            
                System.out.println("Done");
            }
            catch(Exception ex)
            {
                ex.printStackTrace();
            }
        }
        ClientHandler(Socket sock)
        {
            this.sock=sock;
        }
    }
    public static void main(String[] args) 
    {
        Server obj = new Server();
    }
}
