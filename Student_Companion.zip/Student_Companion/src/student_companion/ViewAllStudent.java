package student_companion;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;

public class ViewAllStudent extends javax.swing.JFrame 
{
    ArrayList <Student> al;
    ViewAllStudent.Mymodel sbtm;
    public ViewAllStudent() 
    {
        initComponents();
        this.setSize(600,600);
        this.setVisible(true);
        al = new ArrayList<>();
        sbtm = new ViewAllStudent.Mymodel();
        jt.setModel(sbtm);
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver loading");
            Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student_companion", "root", "system");
            System.out.println("connection built");
            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stmt.executeQuery("select * from department");
            cb_Department.addItem("Select");
            while(rs.next())
            {
                String d=rs.getString("Department_Name");
                cb_Department.addItem(d);
            }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        cb_Department = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        cb_Course = new javax.swing.JComboBox<>();
        fetch = new javax.swing.JButton();
        delete1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jt = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("VIEW ALL STUDENTS");

        jLabel2.setText("Select Department");

        cb_Department.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cb_DepartmentItemStateChanged(evt);
            }
        });

        jLabel3.setText("Select Courses");

        fetch.setText("FETCH");
        fetch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fetchActionPerformed(evt);
            }
        });

        delete1.setText("DELETE");
        delete1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete1ActionPerformed(evt);
            }
        });

        jt.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jt.setGridColor(new java.awt.Color(51, 51, 51));
        jScrollPane1.setViewportView(jt);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 580, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(40, 40, 40)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(164, 164, 164)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(cb_Department, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cb_Course, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(148, 148, 148)
                                .addComponent(jLabel1))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(251, 251, 251)
                                .addComponent(fetch, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(245, 245, 245)
                .addComponent(delete1, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cb_Department, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cb_Course, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 62, Short.MAX_VALUE)
                .addComponent(fetch, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addComponent(delete1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(51, 51, 51))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cb_DepartmentItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cb_DepartmentItemStateChanged
        String crs; 
        while(true)
        {    
            try
            {
                crs =(String)cb_Department.getSelectedItem();
                Class.forName("com.mysql.jdbc.Driver");
                System.out.println("Driver loading");
                Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student_companion", "root", "system");
                System.out.println("connection built");
                Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                ResultSet rs = stmt.executeQuery("select * from course where Department='"+crs+"'");
                cb_Course.removeAllItems();
                cb_Course.addItem("Select");
                while(rs.next())
                {
                    cb_Course.addItem(rs.getString("Course_Name"));
                }
                break;
            }
            catch(Exception ex)
            {
                ex.printStackTrace();
            }
            try
            {
                Thread.sleep(1000);
            }
            catch(Exception ex)
            {
                ex.printStackTrace();
            }
        }
    }//GEN-LAST:event_cb_DepartmentItemStateChanged
    class Mymodel extends AbstractTableModel
    {
        String title[] = {"STUDENT NAME","ROLL NUMBER","GENDER","PHONE NUMBER","EMAIL"};
        public String getColumnName(int index)
        {
            return title[index];
        }
        public int getColumnCount()
        {
            return 5;
        }
        public int getRowCount()
        {
            return al.size();
        }
        public Object getValueAt(int row, int col)
        {
            Student s= al.get(row);
            if(col==0)
                return s.name ;
            else if(col==1)
                return s.rollno;
            else if(col==2)
                return s.gender;
            else if(col==3)
                return s.phoneNumber;
            else
                return s.email;
        }
    }
    public void fetchData()
    {
        al.clear();
        String s1 =(String) cb_Course.getSelectedItem();
        String s2 =(String) cb_Department.getSelectedItem();
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver loading");
            Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student_companion", "root", "system");
            System.out.println("connection built");
            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stmt.executeQuery("select * from student where Course_name ='"+s1+"'");
            while(rs.next())
            {
                Student dt= new Student();
                dt.name= rs.getString("Name");
                dt.rollno= rs.getString("Roll_no");
                dt.email= rs.getString("Email");
                dt.phoneNumber= rs.getString("Phone_Number");
                dt.gender= rs.getString("Gender");
                al.add(dt);
            }
            sbtm.fireTableDataChanged();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
    private void fetchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fetchActionPerformed
        al.clear();
        String s1 =(String) cb_Course.getSelectedItem();
        String s2 =(String) cb_Department.getSelectedItem();
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver loading");
            Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student_companion", "root", "system");
            System.out.println("connection built");
            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = stmt.executeQuery("select * from student where Course_name ='"+s1+"'");
            while(rs.next())
            {
                Student dt= new Student();
                dt.name= rs.getString("Name");
                dt.rollno= rs.getString("Rollno");
                dt.email= rs.getString("Email");
                dt.phoneNumber= rs.getString("Phone_Number");
                dt.gender= rs.getString("Gender");
                al.add(dt);
            }
            sbtm.fireTableDataChanged();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }//GEN-LAST:event_fetchActionPerformed

    private void delete1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete1ActionPerformed
        String dt;
        int index = jt.getSelectedRow();
        if(index==-1)
        {
            System.out.println("Please Select row"); 
        }
        else
        {
            dt = al.get(index).rollno;
            System.out.println(dt);
            int flag = JOptionPane.showConfirmDialog(ViewAllStudent.this,"Are you Sure?");
            if(flag ==JOptionPane.YES_OPTION)
            {
                try
                {
                    Class.forName("com.mysql.jdbc.Driver");
                    System.out.println("Driver loading");
                    Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student_companion", "root", "system");
                    System.out.println("connection built");
                    Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                    ResultSet rs = stmt.executeQuery("select * from student where rollno = '"+dt+"'");
                    if(rs.next())
                    {
                        rs.deleteRow();
                        JOptionPane.showMessageDialog(ViewAllStudent.this, "Delete Successfully");
                        ViewAllStudent.this.fetchData();
                    }
                }
                catch(Exception ex)
                {
                    ex.printStackTrace();
                }
            }
        }
    }//GEN-LAST:event_delete1ActionPerformed

    public static void main(String args[]) 
    {
        java.awt.EventQueue.invokeLater(new Runnable() 
        {
            public void run() 
            {
                new ViewAllStudent().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cb_Course;
    private javax.swing.JComboBox<String> cb_Department;
    private javax.swing.JButton delete1;
    private javax.swing.JButton fetch;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jt;
    // End of variables declaration//GEN-END:variables
}
