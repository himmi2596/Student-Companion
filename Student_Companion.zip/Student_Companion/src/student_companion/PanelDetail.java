package student_companion;

import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class PanelDetail extends javax.swing.JFrame {
    String paperid,request,path;
    public PanelDetail(String paperid) 
    {
        initComponents();
        this.paperid=paperid;
        request="getdetail";
        new Thread(new Client()).start();
        this.setSize(550,550);
        this.setVisible(true);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        lb_Title = new javax.swing.JLabel();
        lb_Description = new javax.swing.JLabel();
        lb_Type = new javax.swing.JLabel();
        lb_Subcode = new javax.swing.JLabel();
        lb_Semester = new javax.swing.JLabel();
        lb_Date = new javax.swing.JLabel();
        lb_Upload = new javax.swing.JLabel();
        lb_Year = new javax.swing.JLabel();
        bt_download = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        pb = new javax.swing.JProgressBar();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setText("TYPE");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(31, 130, 99, 26);

        jLabel2.setText("DESCRIPTION");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(31, 86, 99, 26);

        jLabel3.setText("SEMESTER");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(31, 237, 99, 26);

        jLabel4.setText("YEAR OF EXAMINATION");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(20, 400, 130, 26);

        jLabel5.setText("UPLOADED BY");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(31, 335, 99, 26);

        jLabel7.setText("SYBJECT CODE");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(31, 185, 99, 26);

        lb_Title.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lb_Title.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(lb_Title);
        lb_Title.setBounds(180, 10, 180, 30);

        lb_Description.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(lb_Description);
        lb_Description.setBounds(160, 80, 310, 30);

        lb_Type.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(lb_Type);
        lb_Type.setBounds(160, 130, 310, 30);

        lb_Subcode.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(lb_Subcode);
        lb_Subcode.setBounds(160, 180, 310, 30);

        lb_Semester.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(lb_Semester);
        lb_Semester.setBounds(160, 230, 310, 30);

        lb_Date.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(lb_Date);
        lb_Date.setBounds(160, 290, 310, 30);

        lb_Upload.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(lb_Upload);
        lb_Upload.setBounds(160, 340, 310, 30);

        lb_Year.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(lb_Year);
        lb_Year.setBounds(160, 400, 310, 30);

        bt_download.setText("DOWNLOAD");
        bt_download.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_downloadActionPerformed(evt);
            }
        });
        getContentPane().add(bt_download);
        bt_download.setBounds(160, 500, 240, 30);

        jLabel8.setText("DATE OF EXAMINATION");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(31, 291, 116, 26);

        pb.setForeground(new java.awt.Color(0, 0, 0));
        pb.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        pb.setStringPainted(true);
        getContentPane().add(pb);
        pb.setBounds(160, 450, 240, 30);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bt_downloadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_downloadActionPerformed
        request="download";
        new Thread(new Client()).start();
    }//GEN-LAST:event_bt_downloadActionPerformed
    public class Client implements Runnable {
        
        Socket sock;
        DataOutputStream dos;
        DataInputStream dis;
        FileOutputStream fos;
        Client() 
        {
            
        }
        
        public void run() {
            String res;
            try {
                    System.out.println("Client Request Send");
                    sock = new Socket("127.0.0.1", 9999);
                    System.out.println("Request Accepted by Server");
                    dos = new DataOutputStream(sock.getOutputStream());
                    dis = new DataInputStream(sock.getInputStream());
                    System.out.println("Stream Connected");
                
                    if(request.equals("getdetail"))
                    {
                        dos.writeBytes(request+"\r\n");
                        dos.writeBytes(paperid+"\r\n");
                        System.out.println(paperid);
                        
                        lb_Title.setText(dis.readLine());
                        lb_Description.setText(dis.readLine());
                        lb_Subcode.setText(dis.readLine());
                        lb_Type.setText(dis.readLine());
                        lb_Semester.setText(dis.readLine());
                        lb_Year.setText(dis.readLine());
                        lb_Date.setText(dis.readLine());
                        lb_Upload.setText(dis.readLine());
                        path=dis.readLine();
                        System.out.println(path);
                    }
                    else if(request.equals("download"))
                    {
                        dos.writeBytes(request+"\r\n");
                        dos.writeBytes(path+"\r\n");
                        
                        String name=dis.readLine();
                        System.out.println(name);
                        long len=dis.readLong();
                        pb.setMaximum((int)len);
                        fos = new FileOutputStream(new File("C:\\Users\\HP\\Downloads\\Programs\\"+name));
                        
                        int count=0;
                        byte b[]= new byte[10000];
                        while(true)
                        {
                            int x=dis.read(b,0,10000);
                            count=count+x;
                            pb.setValue(count);
                            fos.write(b,0, x);
                            if(count==len)
                                break;
                            Thread.sleep(100);
                        }
                        
                        JOptionPane.showMessageDialog(PanelDetail.this, "Downloads Successfully!!");
                        fos.close();
                    }
                }
                catch (Exception ex) 
                {
                    ex.printStackTrace();
                }
            }
        }
        

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bt_download;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel lb_Date;
    private javax.swing.JLabel lb_Description;
    private javax.swing.JLabel lb_Semester;
    private javax.swing.JLabel lb_Subcode;
    private javax.swing.JLabel lb_Title;
    private javax.swing.JLabel lb_Type;
    private javax.swing.JLabel lb_Upload;
    private javax.swing.JLabel lb_Year;
    private javax.swing.JProgressBar pb;
    // End of variables declaration//GEN-END:variables
}
