package student_companion;
public class Department 
{
    String Department_Name,Description;
    public Department(String Department_Name,String Description)
    {
        this.Department_Name = Department_Name;
        this.Description = Description;
    }
    public Department()
    {
    }
}
