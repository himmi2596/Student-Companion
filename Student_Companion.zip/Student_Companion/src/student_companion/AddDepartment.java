package student_companion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class AddDepartment extends javax.swing.JInternalFrame 
{
    public AddDepartment() 
    {
        initComponents();
        this.setSize(500,500);
        this.setVisible(true);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        add = new javax.swing.JButton();
        tf_DepartmentName = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tf_Description = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("ADD DEPARTMENT");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(110, 20, 350, 60);

        jLabel2.setText("DEPARTMENT NAME");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(20, 114, 120, 40);

        jLabel3.setText("DESCRIPTION");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(20, 170, 100, 40);

        add.setText("ADD");
        add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addActionPerformed(evt);
            }
        });
        getContentPane().add(add);
        add.setBounds(163, 363, 90, 40);
        getContentPane().add(tf_DepartmentName);
        tf_DepartmentName.setBounds(160, 120, 150, 30);

        tf_Description.setColumns(20);
        tf_Description.setRows(5);
        jScrollPane1.setViewportView(tf_Description);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(160, 180, 166, 96);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addActionPerformed
        if(tf_DepartmentName.getText().isEmpty() || tf_Description.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(AddDepartment.this, "All Fields are Required!!");
            tf_DepartmentName.setText("");
            tf_Description.setText("");
        }
        else
        {
            String s1=tf_DepartmentName.getText();
            String s2=tf_Description.getText();
            try
            {
               Class.forName("com.mysql.jdbc.Driver");
               System.out.println("Driver loading");
               Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student_companion", "root", "system");
               System.out.println("connection built");
               Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
               ResultSet rs = stmt.executeQuery("select * from department where Department_Name = '"+s1+"'");
               if(rs.next())
               {
                    JOptionPane.showMessageDialog(AddDepartment.this, "Already Exists");   
               }
               else
               {
                   rs.moveToInsertRow();
                   rs.updateString("Department_Name", s1);
                   rs.updateString("Description", s2);
                   rs.insertRow();
                   JOptionPane.showMessageDialog(AddDepartment.this, "Task Complete");
               }
            }
            catch(Exception ex)
            {
                ex.printStackTrace();
            }
        }
    }//GEN-LAST:event_addActionPerformed

    public static void main(String args[]) 
    {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddDepartment().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton add;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField tf_DepartmentName;
    private javax.swing.JTextArea tf_Description;
    // End of variables declaration//GEN-END:variables
}
